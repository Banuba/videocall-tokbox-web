function Effect()
{
    this.init = function() {
        // spawning model (plane) for bg separation
        setBGTexture("Apartment.png");
        // setting BG coloring RGBA options using MULTIPLY blending.
        // If you don't need to change texture's color, set Alpha channel (last value of 4) to 0.
        Api.meshfxMsg("shaderVec4", 0, 0, "1.0 0.0 0.0 0.");

        Api.showRecordButton();
    };
    this.faceActions = [];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [];
}

function setBGTexture(name) {
    Api.meshfxMsg("spawn", 0, 0, "tri.bsm2");
    Api.setRecognizerFeatures(["background"]);
    Api.meshfxMsg("tex", 0, 0, name);
}

function disableBackground(){
    Api.meshfxMsg("del", 0);
    Api.setRecognizerFeatures([]);
}

var textureModes = {
    1: "Aspect Fill", // default
    2: "Aspect Fit",
    3: "Scale to Fill"
}

function setBGTextureMode(option) { // "Aspect Fill" option is default
    if(textureModes.hasOwnProperty(option)){
        Api.print("setBGTextureMode - " + textureModes[option] + " texture mode is selected");
        Api.meshfxMsg("shaderVec4", 0, 0, option + " 0 0 0");
    } else {
        Api.print("setBGTextureMode - there is no texture mode under option key " + option);
    }
}

configure(new Effect());