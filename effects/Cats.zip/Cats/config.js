function Effect() {
    var self = this;

    this.init = function() {
        Api.meshfxMsg("spawn", 1, 0, "tri.bsm2");
        Api.playVideo("frx", true, 1);
        // Api.showHint("Open mouth");

        Api.showRecordButton();
    };

    this.restart = function() {
        Api.meshfxReset();

        self.init();
    };

    this.faceActions = [];
    this.noFaceActions = [];

    this.videoRecordStartActions = [];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [this.restart];
}

configure(new Effect());